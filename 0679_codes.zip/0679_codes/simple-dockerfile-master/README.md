simple-dockerfile
=================

A trivial Dockerfile example.

docker build .
