-- this is to drop the tables ready for a re-installation - ie not the django tables.
drop table tmortgagejrnl;
drop table tmortgage;
drop table turl;
drop table tinstitution;

