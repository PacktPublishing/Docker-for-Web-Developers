drop database themortgagemeter;
