create database themortgagemeter;
